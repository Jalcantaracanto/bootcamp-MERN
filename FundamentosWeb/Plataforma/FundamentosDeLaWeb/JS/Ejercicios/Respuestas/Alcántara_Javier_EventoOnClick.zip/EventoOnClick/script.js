// Desaparecer Boton
function hide(element) {
    element.remove();
}

// Cambiar Login
function ChangeLogin(element) {
    element.innerText = "Logout";
}
// Alerta
function message() {
    alert('Ninja was liked');
}
